<aside id="sidebar-wrapper">
    <div class="sidebar-brand">
    <img style="margin-top:0px;" src="<?php echo e(asset('img/LOGOS.gif')); ?>">
        <a href="<?php echo e(url('/')); ?>"></a>
        </div>
        <div class="sidebar-brand sidebar-brand-sm">
        <a href="index.html">MMS</a>
    </div>
    <ul class="sidebar-menu" style="margin-bottom:50px;margin-top:30px;">
        <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </ul>
</aside>
<?php /**PATH C:\xampp\htdocs\MMS\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>