<li class="dropdown dropdown-list-toggle"><a href="#" data-toggle="dropdown" class="nav-link notification-toggle nav-link-lg beep"><i class="far fa-bell"></i></a>
    <div class="dropdown-menu dropdown-list dropdown-menu-right">
        <div class="dropdown-header">Notifications
            <div class="float-right">
                <a href="#">Mark All As Read</a>
            </div>
        </div>
        <div class="dropdown-list-content dropdown-list-icons" id="notificationContainer">
        
        </div>
    </div>
</li>
<?php /**PATH C:\xampp\htdocs\MMS\resources\views/layouts/notification.blade.php ENDPATH**/ ?>