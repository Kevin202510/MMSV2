
    <table class="table table-striped">
        <thead>
            <tr>
                <th>fname</th>
                <th>mname</th>
                <th>lname</th>
                <th>address</th>
                <th>contact</th>
                <th>username</th>
                <th>isApproved</th>
            </tr>
        </thead>
        <tbody id="table-main">
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($users->fname); ?></td>
            <td><?php echo e($users->mname); ?></td>
            <td><?php echo e($users->lname); ?></td>
            <td><?php echo e($users->address); ?></td>
            <td><?php echo e($users->contact); ?></td>
            <td><?php echo e($users->username); ?></td>
            <td><?php echo e($users->isApproved); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php /**PATH C:\xampp\htdocs\MMS\resources\views/users/exportusersData.blade.php ENDPATH**/ ?>