<ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="{{ route('home') }}"><i class="fas fa-tachometer-alt"></i> Home</a></li>
    <li class="breadcrumb-item">{{Route::currentRouteName()}}</li>
</ol>