<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>@yield('title') | {{ config('app.name') }}</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="/img/favicons.ico">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500&family=Lora:wght@600;700&display=swap" rel="stylesheet"> 

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="{{ asset('landingpageassets/lib/animate/animate.min.css') }}" rel="stylesheet">
    <link href="{{ asset('landingpageassets/lib/owlcarousel/assets/owl.carousel.min.css') }}" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="{{ asset('landingpageassets/css/bootstrap.min.css') }}" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="{{ asset('landingpageassets/css/style.css') }}" rel="stylesheet">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        #vari{
            height:200px;
        }
        .blink_mes {
        animation: blinker 3s linear infinite;
        }

        @keyframes blinker {
        50% {
            opacity: 0;
        }
        }

        .n1{
            color:#b96c47;
        }

        .waviy {
        position: relative;
        -webkit-box-reflect: below -20px linear-gradient(transparent, rgba(0,0,0,.2));
        font-size: 60px;
        }
        .waviy span {
        position: relative;
        display: inline-block;
        text-transform: uppercase;
        animation: waviy 1s infinite;
        animation-delay: calc(1s * var(--i));
        
        }
        @keyframes waviy {
        0%,40%,100% {
            transform: translateY(0)
        }
        20% {
            transform: translateY(-20px)
        }
        }


        .waitingForConnection {
        animation: blinker 2s cubic-bezier(.5, 0, 1, 1) infinite alternate;  
        }
        @keyframes blinker { to { opacity: 0; } }

        .waitingForConnection2 {
        animation: blinker2 1.8s cubic-bezier(1, 0, 0, 1) infinite alternate;  
        }
        @keyframes blinker2 { to { opacity: 0; } }

        .waitingForConnection3 {
        animation: blinker3 1.6 ease-in-out infinite alternate;  
        }
        @keyframes blinker3 { to { opacity: 0; } }
    </style>
    
</head>

<body style="background-color:#e1e4eb;">
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" role="status"></div>
    </div>
    <!-- Spinner End -->

    <!-- Navbar Start -->
    <div class="container-fluid fixed-top px-0 wow fadeIn" data-wow-delay="0.1s">
        <div class="top-bar row gx-0 align-items-center d-none d-lg-flex">
            <div class="col-lg-12 px-5 text-start">
                <small style="color:black;"><i class="fa fa-map-marker-alt me-2"></i>Brgy. Rio Chico General Tinio NE</small>
                <small class="ms-4" style="float:right;"><i class="fa fa-phone me-2"></i>09261364720</small>
            </div>
        </div>

        <nav class="navbar navbar-expand-lg navbar-light py-lg-0 px-lg-5 wow fadeIn" data-wow-delay="0.1s">
            <a href="{{ url('/') }}" class="navbar-brand ms-4 ms-lg-0">
                <div class="waviy">
                    <h1 class="fw-bold m-0 n1"><span class="n1" style="--i:1;">M</span><span class="n1" style="--i:2">M</span><span class="text-primary" style="--i:3">S</span></h1>
                </div>
            </a>
            <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
            @if (Route::has('login'))
                <div class="navbar-nav ms-auto p-4 p-lg-0">
                @auth
                    <a href="{{ url('home') }}" class="nav-item nav-link active">Home</a>
                    @else
                    <a href="{{ route('login') }}" class="nav-item nav-link"><b>Login</b></a>
                @endauth
                </div>
            @endif
                <!-- <div class="d-none d-lg-flex ms-2">
                    <a class="btn-sm-square bg-white rounded-circle ms-3" href="">
                        <small class="fa fa-search text-body"></small>
                    </a>
                    <a class="btn-sm-square bg-white rounded-circle ms-3" href="">
                        <small class="fa fa-user text-body"></small>
                    </a>
                    <a class="btn-sm-square bg-white rounded-circle ms-3" href="">
                        <small class="fa fa-shopping-bag text-body"></small>
                    </a>
                </div> -->
            </div>
        </nav>
    </div>
    <!-- Navbar End -->

    @yield('content')

    @if(Route::currentRouteName()=='login')
        <div class="container-fluid bg-dark footer mt-5 wow fadeIn" data-wow-delay="0.1s">
            <div class="container-fluid copyright">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                            &copy; <a href="#">mushroommonitoringsystem</a>, All Right Reserved.
                        </div>
                        <div class="col-md-6 text-center text-md-end">
                            <!--/*** This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". Thank you for your support. ***/-->
                            Designed By <a href="{{ url('/') }}">Kevin Felix Caluag</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @else
            <!-- Footer Start -->
    <div class="container-fluid bg-dark footer mt-5 wow fadeIn" data-wow-delay="0.1s">
        <!-- <div class="container py-5">
            <div class="row g-5">
                <div class="col-lg-3 col-md-6">
                    <h1 class="fw-bold text-primary mb-4">F<span class="text-secondary">oo</span>dy</h1>
                    <p>Diam dolor diam ipsum sit. Aliqu diam amet diam et eos. Clita erat ipsum et lorem et sit, sed stet lorem sit clita</p>
                    <div class="d-flex pt-2">
                        <a class="btn btn-square btn-outline-light rounded-circle me-1" href=""><i class="fab fa-twitter"></i></a>
                        <a class="btn btn-square btn-outline-light rounded-circle me-1" href=""><i class="fab fa-facebook-f"></i></a>
                        <a class="btn btn-square btn-outline-light rounded-circle me-1" href=""><i class="fab fa-youtube"></i></a>
                        <a class="btn btn-square btn-outline-light rounded-circle me-0" href=""><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-light mb-4">Address</h4>
                    <p><i class="fa fa-map-marker-alt me-3"></i>123 Street, New York, USA</p>
                    <p><i class="fa fa-phone-alt me-3"></i>+012 345 67890</p>
                    <p><i class="fa fa-envelope me-3"></i>info@example.com</p>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-light mb-4">Quick Links</h4>
                    <a class="btn btn-link" href="">About Us</a>
                    <a class="btn btn-link" href="">Contact Us</a>
                    <a class="btn btn-link" href="">Our Services</a>
                    <a class="btn btn-link" href="">Terms & Condition</a>
                    <a class="btn btn-link" href="">Support</a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-light mb-4">Newsletter</h4>
                    <p>Dolor amet sit justo amet elitr clita ipsum elitr est.</p>
                    <div class="position-relative mx-auto" style="max-width: 400px;">
                        <input class="form-control bg-transparent w-100 py-3 ps-4 pe-5" type="text" placeholder="Your email">
                        <button type="button" class="btn btn-primary py-2 position-absolute top-0 end-0 mt-2 me-2">SignUp</button>
                    </div>
                </div>
            </div>
        </div> -->
        <div class="container-fluid copyright">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                        @ <a href="{{ url('/') }}">Mushroom Monitoring System</a>, All rights reserved &copy; {{ date('Y') }}
                    </div>
                    <div class="col-md-6 text-center text-md-end">
                            <!--/*** This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". Thank you for your support. ***/-->
                        Designed By <a href="{{ url('https://kevincaluagprofile.my.canva.site/') }}" target="_blank">Kevin Felix Caluag</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->
    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-lg-square rounded-circle back-to-top" style="background-color: #e2d880;"><i class="bi bi-arrow-up"></i></a>
    @endif
    
    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="{{ asset('landingpageassets/lib/wow/wow.min.js') }}"></script>
    <script src="{{ asset('landingpageassets/lib/easing/easing.min.js') }}"></script>
    <script src="{{ asset('landingpageassets/lib/waypoints/waypoints.min.js') }}"></script>
    <script src="{{ asset('landingpageassets/lib/owlcarousel/owl.carousel.min.js') }}"></script>

    <!-- Template Javascript -->
    <script src="{{ asset('landingpageassets/js/main.js') }}"></script>

    @yield('javascript')
</body>

</html>