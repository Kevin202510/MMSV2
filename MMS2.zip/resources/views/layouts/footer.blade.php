<div class="footer-left">
    All rights reserved &copy; {{ date('Y') }}
</div>
<strong style="float:right;">Powered By : <a href="{{ url('https://kevincaluagprofile.my.canva.site/') }}" target="_blank" style=" text-decoration: none;">Kevin Felix Caluag</a></strong>
