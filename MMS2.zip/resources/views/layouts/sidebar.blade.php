<aside id="sidebar-wrapper">
    <div class="sidebar-brand">
    <img style="margin-top:0px;" src="{{ asset('img/LOGOS.gif') }}">
        <a href="{{ url('/') }}"></a>
        </div>
        <div class="sidebar-brand sidebar-brand-sm">
        <a href="index.html">MMS</a>
    </div>
    <ul class="sidebar-menu" style="margin-bottom:50px;margin-top:30px;">
        @include('layouts.menu')
    </ul>
</aside>
