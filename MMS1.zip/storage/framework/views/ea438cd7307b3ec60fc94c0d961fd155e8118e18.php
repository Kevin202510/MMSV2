<div class="footer-left">
    All rights reserved &copy; <?php echo e(date('Y')); ?>

</div>
<strong style="float:right;">Powered By : <a href="<?php echo e(url('https://kevincaluagprofile.my.canva.site/')); ?>" target="_blank" style=" text-decoration: none;">Kevin Felix Caluag</a></strong>
<?php /**PATH C:\xampp\htdocs\MMS\resources\views/layouts/footer.blade.php ENDPATH**/ ?>