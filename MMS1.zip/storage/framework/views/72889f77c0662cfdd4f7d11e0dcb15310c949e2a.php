

<?php $__env->startSection('title'); ?>
    MMS
<?php $__env->stopSection(); ?>
                                                    
<?php $__env->startSection('content'); ?>
    <!-- Carousel Start -->
    <div class="container-fluid p-0 mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div id="header-carousel" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img class="w-100" src="<?php echo e(asset('landingpageassets/img/a1.png')); ?>" alt="Image">
                    <div class="carousel-caption">
                        <div class="container">
                            <div class="row justify-content-start">
                                <div class="col-lg-8">
                                    <h1 style="margin-left:25px;" class="display-4 mb-5 animated slideInDown blink_me">Mushroom Monitoring System</h1>
                                    <!-- <a href="" class="btn btn-primary rounded-pill py-sm-3 px-sm-5">Products</a>
                                    <a href="" class="btn btn-secondary rounded-pill py-sm-3 px-sm-5 ms-3">Services</a> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <img class="w-100" src="<?php echo e(asset('landingpageassets/img/a3.png')); ?>" alt="Image">
                    <div class="carousel-caption">
                        <div class="container">
                            <div class="row justify-content-start">
                            <div class="col-lg-8">
                                    <h1 style="margin-left:25px;" class="display-4 mb-5 animated slideInDown blink_me">Mushroom Monitoring System</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <img class="w-100" src="<?php echo e(asset('landingpageassets/img/a4.png')); ?>" alt="Image">
                    <div class="carousel-caption">
                        <div class="container">
                            <div class="row justify-content-start">
                            <div class="col-lg-8">
                                    <h1 style="margin-left:25px;" class="display-4 mb-5 animated slideInDown blink_me">Mushroom Monitoring System</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <img class="w-100" src="<?php echo e(asset('landingpageassets/img/a2.png')); ?>" alt="Image">
                    <div class="carousel-caption">
                        <div class="container">
                            <div class="row justify-content-start">
                            <div class="col-lg-8">
                                    <h1 style="margin-left:25px;" class="display-4 mb-5 animated slideInDown blink_me">Mushroom Monitoring System</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <img class="w-100" src="<?php echo e(asset('landingpageassets/img/panglima.png')); ?>" alt="Image">
                    <div class="carousel-caption">
                        <div class="container">
                            <div class="row justify-content-start">
                            <div class="col-lg-8">
                                    <h1 style="margin-left:25px;" class="display-4 mb-5 animated slideInDown blink_me">Mushroom Monitoring System</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#header-carousel"
                data-bs-slide="prev">
                <span class="carousel-control-prev-icon" style="background-color: #e2d880; border: 10px solid #e2d880;" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#header-carousel"
                data-bs-slide="next">
                <span class="carousel-control-next-icon" style="background-color: #e2d880; border: 10px solid #e2d880;" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>
    <!-- Carousel End -->


    <!-- About Start -->
    <div class="container-xxl py-2" style="background-color:#e1e4eb;">
        <div class="container">
            <div class="row g-5 align-items-center">
                <div class="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
                    <div class="position-relative overflow-hidden p-5 pe-0">
                        <video class="img-fluid w-100" style="border-radius:50px;" src="<?php echo e(asset('video/vid2.mp4')); ?>" muted loop autoplay></video>
                        <!-- <img class="img-fluid w-100" src=" asset('landingpageassets/img/mushroomkoto.jpg') }}"> -->
                    </div>
                </div>
                <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
                    <h1 class="display-5 mb-4">Mushroom</h1>
                    <p class="mb-4">Mushrooms are miniature pharmaceutical factories, and of the thousands of mushroom species in nature, our ancestors and modern scientists have identified several dozen that have a unique combination of talents that improve our health.</p>
                    <!-- <p><i class="fa fa-check text-primary me-3"></i>Tempor erat elitr rebum at clita</p>
                    <p><i class="fa fa-check text-primary me-3"></i>Aliqu diam amet diam et eos</p>
                    <p><i class="fa fa-check text-primary me-3"></i>Clita duo justo magna dolore erat amet</p>
                    <a class="btn btn-primary rounded-pill py-3 px-5 mt-3" href="">Read More</a> -->
                </div>
            </div>
        </div>
    </div>

    <div class="container-xxl py-2" style="background-color:#e1e4eb;">
        <div class="container">
            <div class="row g-5 align-items-center">
                <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
                    <h1 class="display-5 mb-4">Mushroom cultivation</h1>
                    <p class="mb-4">Mushroom cultivation is a technology of growing mushrooms using plant, animal and industrial waste. In short it is wealth out of waste technology. This technology has gained importance worldwide because of its dietary fibres and proteins value. Mushroom is a fungi belonging to basidiomycetes.</p>
                    <!-- <p><i class="fa fa-check text-primary me-3"></i>Tempor erat elitr rebum at clita</p>
                    <p><i class="fa fa-check text-primary me-3"></i>Aliqu diam amet diam et eos</p>
                    <p><i class="fa fa-check text-primary me-3"></i>Clita duo justo magna dolore erat amet</p>
                    <a class="btn btn-primary rounded-pill py-3 px-5 mt-3" href="">Read More</a> -->
                </div>
                <div class="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
                    <div class="position-relative overflow-hidden p-5 pe-0">
                        <video class="img-fluid w-100"  style="border-radius:50px;" src="<?php echo e(asset('video/vid1.mp4')); ?>" muted loop autoplay></video>
                        <!-- <img class="img-fluid w-100" src=" asset('landingpageassets/img/mushroomkoto.jpg') }}"> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->

    <!-- Feature Start -->
    <div class="container-fluid my-5 py-6" style="background-color:#e1e4eb;">
        <div class="container">
            <div class="section-header text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 500px;">
                <h1 class="display-5 mb-3">Mushroom House Current Status</h1>
                <!-- <p>Tempor ut dolore lorem kasd vero ipsum sit eirmod sit. Ipsum diam justo sed rebum vero dolor duo.</p> -->
            </div>
            <div class="row g-4">
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="bg-white text-center h-100 p-4 p-xl-5">
                        <img class="img-fluid mb-4" src="<?php echo e(asset('landingpageassets/img/temperature.png')); ?>" alt="">
                        <h6 class="mb-3">Temperature</h6>
                        <p class="mb-4" id="tempval"></p>
                        
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="bg-white text-center h-100 p-4 p-xl-5">
                        <img class="img-fluid mb-4" src="<?php echo e(asset('landingpageassets/img/humidity.png')); ?>" alt="">
                        <h6 class="mb-3">Humidity</h6>
                        <p class="mb-4" id="humidityval"></p>
                        
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="bg-white text-center h-100 p-4 p-xl-5">
                        <img class="img-fluid mb-4" src="<?php echo e(asset('landingpageassets/img/lights.png')); ?>" alt="">
                        <h6 class="mb-3">Lights</h6>
                        <p class="mb-4" id="lightsval"></p>
                        
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="bg-white text-center h-100 p-4 p-xl-5">
                        <img class="img-fluid mb-4" src="<?php echo e(asset('landingpageassets/img/co2.png')); ?>" alt="">
                        <h6 class="mb-3">Carbon Dioxide</h6>
                        <p class="mb-4" id="co2val"></p>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Feature End -->

    <!-- Product Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="row g-0 gx-5 align-items-end">
                <div class="col-lg-6">
                    <div class="section-header text-start mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 500px;">
                        <h1 class="display-5 mb-3 blink_mes">Our Mushrooms Varieties</h1>
                        <!-- <p>Tempor ut dolore lorem kasd vero ipsum sit eirmod sit. Ipsum diam justo sed rebum vero dolor duo.</p> -->
                    </div>
                </div>
            </div>
            <div class="tab-content">
                <div id="tab-1" class="tab-pane fade show p-0 active">
                    <div class="row g-4 justify-content-center" id="mushroomvar">
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Product End -->

    <!-- Feature Start -->
    <div class="container-fluid my-5 py-2" style="background-color:#e1e4eb;">
        <div class="container">
            <div class="section-header text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 500px;">
                <h1 class="display-5 mb-3 blink_mes">Our Location</h1>
                <p><i class="fa fa-map-marker-alt me-2"></i> Brgy. Rio Chico General Tinio NE</p>
            </div>
            <div class="row g-4 justify-content-center">
            <div class="card" style="background-color:#e1e4eb;">
                <div class="card-body justify-content-center" style="background-color:#e1e4eb;">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d203.20521131124073!2d121.06437780409863!3d15.352883191719751!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x339725cc070c96a9%3A0xd7d36ea9f80403ff!2sBote%20Mushroom%20House!5e1!3m2!1sen!2sph!4v1670058015363!5m2!1sen!2sph" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
                <div class="card-footer">
                <center><h4><strong>Bote Mushroom Farm</strong></h4></center>
                <p class="text-center">
                        Is one of the mushroom farms in the Municipality of General Tino province of Nueva Ecija, Philippines, located at
                        Purok 4 Barangay Rio Chico. Bote Mushroom Farm aims to increase the production rates
                        of mushrooms in the Municipality of General Tinio.Bote Mushroom house is composed of 1 room with a width of fifteen (15) meters
                        and fifteen (15) meters in Height, they started it this year (2012)
                    </p>
                </div>
            </div>
            </div>
        </div>
    </div>
    <!-- Feature End -->


    <!-- Firm Visit Start -->
    <!-- <div class="container-fluid bg-primary  mt-5 py-6">
        <div class="container">
            <div class="row g-5 align-items-center">
                <div class="col-md-7 wow fadeIn" data-wow-delay="0.1s">
                    <h1 class="display-5 text-white mb-3">Visit Our Firm</h1>
                    <p class="text-white mb-0">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit. Aliqu diam amet diam et eos. Clita erat ipsum et lorem et sit, sed stet lorem sit clita duo justo magna dolore erat amet. Diam dolor diam ipsum sit. Aliqu diam amet diam et eos.</p>
                </div>
                <div class="col-md-5 text-md-end wow fadeIn" data-wow-delay="0.5s">
                    <a class="btn btn-lg btn-secondary rounded-pill py-3 px-5" href="">Visit Now</a>
                </div>
            </div>
        </div>
    </div> -->
    <!-- Firm Visit End -->


    <!-- Testimonial Start -->
    <!-- <div class="container-fluid bg-light  py-6 mb-5">
        <div class="container">
            <div class="section-header text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 500px;">
                <h1 class="display-5 mb-3">Customer Review</h1>
                <p>Tempor ut dolore lorem kasd vero ipsum sit eirmod sit. Ipsum diam justo sed rebum vero dolor duo.</p>
            </div>
            <div class="owl-carousel testimonial-carousel wow fadeInUp" data-wow-delay="0.1s">
                <div class="testimonial-item position-relative bg-white p-5 mt-4">
                    <i class="fa fa-quote-left fa-3x text-primary position-absolute top-0 start-0 mt-n4 ms-5"></i>
                    <p class="mb-4">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit diam amet diam et eos. Clita erat ipsum et lorem et sit.</p>
                    <div class="d-flex align-items-center">
                        <img class="flex-shrink-0 rounded-circle" src="<?php echo e(asset('landingpageassets/img/testimonial-1.jpg')); ?>" alt="">
                        <div class="ms-3">
                            <h5 class="mb-1">Client Name</h5>
                            <span>Profession</span>
                        </div>
                    </div>
                </div>
                <div class="testimonial-item position-relative bg-white p-5 mt-4">
                    <i class="fa fa-quote-left fa-3x text-primary position-absolute top-0 start-0 mt-n4 ms-5"></i>
                    <p class="mb-4">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit diam amet diam et eos. Clita erat ipsum et lorem et sit.</p>
                    <div class="d-flex align-items-center">
                        <img class="flex-shrink-0 rounded-circle" src="<?php echo e(asset('landingpageassets/img/testimonial-2.jpg')); ?>" alt="">
                        <div class="ms-3">
                            <h5 class="mb-1">Client Name</h5>
                            <span>Profession</span>
                        </div>
                    </div>
                </div>
                <div class="testimonial-item position-relative bg-white p-5 mt-4">
                    <i class="fa fa-quote-left fa-3x text-primary position-absolute top-0 start-0 mt-n4 ms-5"></i>
                    <p class="mb-4">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit diam amet diam et eos. Clita erat ipsum et lorem et sit.</p>
                    <div class="d-flex align-items-center">
                        <img class="flex-shrink-0 rounded-circle" src="<?php echo e(asset('landingpageassets/img/testimonial-3.jpg')); ?>" alt="">
                        <div class="ms-3">
                            <h5 class="mb-1">Client Name</h5>
                            <span>Profession</span>
                        </div>
                    </div>
                </div>
                <div class="testimonial-item position-relative bg-white p-5 mt-4">
                    <i class="fa fa-quote-left fa-3x text-primary position-absolute top-0 start-0 mt-n4 ms-5"></i>
                    <p class="mb-4">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit diam amet diam et eos. Clita erat ipsum et lorem et sit.</p>
                    <div class="d-flex align-items-center">
                        <img class="flex-shrink-0 rounded-circle" src="<?php echo e(asset('landingpageassets/img/testimonial-4.jpg')); ?>" alt="">
                        <div class="ms-3">
                            <h5 class="mb-1">Client Name</h5>
                            <span>Profession</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> -->
    <!-- Testimonial End -->


    <!-- Blog Start -->
    <!-- <div class="container-xxl py-5">
        <div class="container">
            <div class="section-header text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 500px;">
                <h1 class="display-5 mb-3">Latest Blog</h1>
                <p>Tempor ut dolore lorem kasd vero ipsum sit eirmod sit. Ipsum diam justo sed rebum vero dolor duo.</p>
            </div>
            <div class="row g-4">
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <img class="img-fluid" src="<?php echo e(asset('landingpageassets/img/blog-1.jpg')); ?>" alt="">
                    <div class="bg-light p-4">
                        <a class="d-block h5 lh-base mb-4" href="">How to cultivate organic fruits and vegetables in own firm</a>
                        <div class="text-muted border-top pt-4">
                            <small class="me-3"><i class="fa fa-user text-primary me-2"></i>Admin</small>
                            <small class="me-3"><i class="fa fa-calendar text-primary me-2"></i>01 Jan, 2045</small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                    <img class="img-fluid" src="<?php echo e(asset('landingpageassets/img/blog-2.jpg')); ?>" alt="">
                    <div class="bg-light p-4">
                        <a class="d-block h5 lh-base mb-4" href="">How to cultivate organic fruits and vegetables in own firm</a>
                        <div class="text-muted border-top pt-4">
                            <small class="me-3"><i class="fa fa-user text-primary me-2"></i>Admin</small>
                            <small class="me-3"><i class="fa fa-calendar text-primary me-2"></i>01 Jan, 2045</small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                    <img class="img-fluid" src="<?php echo e(asset('landingpageassets/img/blog-3.jpg')); ?>" alt="">
                    <div class="bg-light p-4">
                        <a class="d-block h5 lh-base mb-4" href="">How to cultivate organic fruits and vegetables in own firm</a>
                        <div class="text-muted border-top pt-4">
                            <small class="me-3"><i class="fa fa-user text-primary me-2"></i>Admin</small>
                            <small class="me-3"><i class="fa fa-calendar text-primary me-2"></i>01 Jan, 2045</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> -->
    <!-- Blog End -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script type="module" src="<?php echo e(asset('js/welcome/index.js')); ?>"></script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MMS\resources\views/welcome.blade.php ENDPATH**/ ?>