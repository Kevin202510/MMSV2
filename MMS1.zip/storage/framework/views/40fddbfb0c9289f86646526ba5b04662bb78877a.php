<ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><i class="fas fa-tachometer-alt"></i> Home</a></li>
    <li class="breadcrumb-item"><?php echo e(Route::currentRouteName()); ?></li>
</ol><?php /**PATH C:\xampp\htdocs\MMS\resources\views/layouts/breadcrum.blade.php ENDPATH**/ ?>